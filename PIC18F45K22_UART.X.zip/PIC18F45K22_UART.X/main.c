/*
 * File:   main.c
 * Author: Ceyhun Pempeci
 *
 * Created on January 10, 2025, 9:25 AM
 */


#include "CONFIG.h"

#define _XTAL_FREQ 64000000

void UART_TX_Init(void)
{

    TXSTA1bits.BRGH = 1;
    BAUDCON1bits.BRG16 =0;
    SPBRG1 = 201; // Baud Rate = 19800 bps
    // -- [Set The RX-TX Pins to be in UART mode (not io) ] --
    TRISB6 = 1;
    TRISB7 = 1;
    // -- [Enable The Asynchronous Serial Port ] --
    TXSTA1bits.SYNC = 0 ;
    RCSTA1bits.SPEN = 1;
    TXSTA1bits.TXEN = 1; //Enable UART Transmission 

}

void UART_Write(uint8_t data)
{
    while(!TXSTA1bits.TRMT);
    TXREG1 = data;
}

void UART_Write_String(uint8_t *text)
{
  uint16_t i;
  for(i=0; text[i]!='\0';i++)
      UART_Write(text[i]);
  
  
    
    
}


void main(void) {
    
    
UART_TX_Init();

while(1)
{

UART_Write_String("Ceyhun Pempeci!!! --TESTING PIC18F45F22 UART--");
__delay_ms(100);

}  
    
    return;
}
